﻿using Microsoft.AspNetCore.Mvc;

namespace Shop.Controllers
{
    public class ContactsController : Controller
    {
        public IActionResult Index() => View();      
    }
}
